<?php

$CONFIG['debug'] = 'on'; // on or off, if it is on all mysql errors will be reported

$CONFIG['dbhostname'] = 'localhost';
$CONFIG['dbusername'] = 'username';
$CONFIG['dbpassword'] = 'password';
$CONFIG['dbname'] = 'databasename';

// connect to the database
$db = mysql_connect($CONFIG['dbhostname'],$CONFIG['dbusername'],$CONFIG['dbpassword']) or displayerror('could not connect');
mysql_select_db($CONFIG['dbname'],$db);

// the name of the mysql database table
$CONFIG['tablename'] = 'customer';

// a descriptive name given to a single record table, e.g Product, Customer, News Article etc
$CONFIG['recordname'] = 'Customer';

// the field name of the primary key in the database table
$CONFIG['primarykey'] = 'customer_id';

// the field name of the field which will be used to search for records
$CONFIG['searchfield'] = 'company_name';

$CONFIG['title'] = 'Customer Editor';

$CONFIG['pagesize'] = 100; // how many records per page?


$FIELDS['customer_id']['description'] = 'Customer ID';
$FIELDS['customer_id']['listdisplay'] = 0;
$FIELDS['customer_id']['editdisplay'] = 0; 
$FIELDS['customer_id']['editable'] = 0; 
$FIELDS['customer_id']['type'] = 'input';
$FIELDS['customer_id']['length'] = 10;
$FIELDS['customer_id']['required'] = 0;
$FIELDS['customer_id']['explanation'] = '';

$FIELDS['company_name']['description'] = 'Company Name';
$FIELDS['company_name']['listdisplay'] = 1;
$FIELDS['company_name']['editdisplay'] = 1;
$FIELDS['company_name']['editable'] = 1; 
$FIELDS['company_name']['type'] = 'input';
$FIELDS['company_name']['length'] = 60;
$FIELDS['company_name']['required'] = 1;
$FIELDS['company_name']['explanation'] = '';

$FIELDS['web_address']['description'] = 'Web Address';
$FIELDS['web_address']['listdisplay'] = 1;
$FIELDS['web_address']['editdisplay'] = 1;
$FIELDS['web_address']['editable'] = 1; 
$FIELDS['web_address']['type'] = 'text';
$FIELDS['web_address']['length'] = 200;
$FIELDS['web_address']['required'] = 0;
$FIELDS['web_address']['explanation'] = '';
$FIELDS['web_address']['listdisplaysize'] = '20';

$FIELDS['email_address']['description'] = 'Email Address';
$FIELDS['email_address']['listdisplay'] = 1;
$FIELDS['email_address']['editdisplay'] = 1;
$FIELDS['email_address']['editable'] = 1; 
$FIELDS['email_address']['type'] = 'input';
$FIELDS['email_address']['length'] = 100;
$FIELDS['email_address']['required'] = 0;
$FIELDS['email_address']['explanation'] = '';



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $CONFIG['title']; ?></title>
</head>

<body>

<?php include('tm_files/tablemanager.php'); ?>

</body>
</html>
